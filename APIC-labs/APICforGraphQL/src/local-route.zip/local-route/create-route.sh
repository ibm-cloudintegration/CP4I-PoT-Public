#!/bin/bash
#
if [ $# -eq 0 ]
  then
 echo " Missing your account name"
 exit
fi 
if [ $# -eq 1 ]
  then
 export ACCOUNT=$1
 else 
 echo " To many arguments passed in"
 exit
fi
#
echo "----------------------------------------------"
export ROUTE_URL=`oc cluster-info | grep http | cut -d "." -f2-6 | cut -d ":" -f1`
###echo "Route = $ROUTE_URL"
export TARGET_NAMESPACE=apic-graphql

( echo 'cat <<EOF' ; cat local-route-template.yaml ) | sh > local-route.yaml
          
oc apply -f local-route.yaml  -n $TARGET_NAMESPACE

rm local-route.yaml
